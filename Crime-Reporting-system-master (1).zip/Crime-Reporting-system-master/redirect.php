<?php
	header('Location:administrator/index.php');
?>